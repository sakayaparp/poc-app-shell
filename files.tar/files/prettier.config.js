module.exports = {
  printWidth: 120,
  singleQuote: true,
  trailingComma: 'all',
  bracketSpacing: true,
  parser: 'typescript',
  semi: true,
  jsxBracketSameLine: true,
};
